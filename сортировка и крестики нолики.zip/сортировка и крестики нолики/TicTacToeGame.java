import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TicTacToeGame extends JFrame {
    private static final int SIZE = 3;
    private static final String PLAYER_X = "X";
    private static final String PLAYER_O = "O";
    private String currentPlayer = PLAYER_X;
    private JButton[][] buttons = new JButton[SIZE][SIZE];
    private JLabel statusLabel;

    public TicTacToeGame() {
        setTitle("Крестики-нолики");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        statusLabel = new JLabel("Ходит игрок X");
        add(statusLabel, BorderLayout.SOUTH);

        JPanel gridPanel = new JPanel();
        gridPanel.setLayout(new GridLayout(SIZE, SIZE));
        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                JButton button = new JButton();
                button.setPreferredSize(new Dimension(100, 100));
                button.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        if (button.getText().isEmpty()) {
                            makeMove(button);
                        }
                    }
                });
                buttons[i][j] = button;
                gridPanel.add(button);
            }
        }
        add(gridPanel, BorderLayout.CENTER);
        pack();
        setVisible(true);
    }

    private void makeMove(JButton button) {
        button.setText(currentPlayer);
        if (checkWin()) {
            statusLabel.setText("Победа игроку " + currentPlayer + "!");
            disableButtons();
        } else if (isDraw()) {
            statusLabel.setText("Ничья");
            disableButtons();
        } else {
            currentPlayer = currentPlayer.equals(PLAYER_X) ? PLAYER_O : PLAYER_X;
            statusLabel.setText("Ход игрока " + currentPlayer);
        }
    }

    private boolean checkWin() {
        return false;
    }

    private boolean isDraw() {
        return false;
    }

    private void disableButtons() {
        for (JButton[] row : buttons) {
            for (JButton button : row) {
                button.setEnabled(false);
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new TicTacToeGame();
            }
        });
    }
}
