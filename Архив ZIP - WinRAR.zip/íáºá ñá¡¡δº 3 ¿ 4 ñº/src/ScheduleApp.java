import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class ScheduleApp extends JFrame {
    private JTabbedPane tabbedPane;
    private Connection connection;

    public ScheduleApp() {
        setTitle("Schedule Management");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        tabbedPane = new JTabbedPane();

        JPanel teacherPanel = createPanel("Teachers", new String[]{"Name", "Department"}, new String[]{"name", "department"});
        JPanel coursePanel = createPanel("Courses", new String[]{"Title", "Teacher", "Classroom"}, new String[]{"title", "teacher", "classroom"});
        JPanel classroomPanel = createPanel("Classrooms", new String[]{"Building", "Room Number"}, new String[]{"building", "room_number"});

        tabbedPane.addTab("Teachers", teacherPanel);
        tabbedPane.addTab("Courses", coursePanel);
        tabbedPane.addTab("Classrooms", classroomPanel);

        add(tabbedPane, BorderLayout.CENTER);

        connectToDatabase();
    }

    private JPanel createPanel(String tableName, String[] columnNames, String[] dbFields) {
        JPanel panel = new JPanel(new BorderLayout());

        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);
        JTable table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        panel.add(scrollPane, BorderLayout.CENTER);

        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(dbFields.length, 2));

        JTextField[] textFields = new JTextField[dbFields.length];
        for (int i = 0; i < dbFields.length; i++) {
            inputPanel.add(new JLabel(columnNames[i] + ":"));
            textFields[i] = new JTextField();
            inputPanel.add(textFields[i]);
        }

        panel.add(inputPanel, BorderLayout.NORTH);

        JPanel buttonPanel = new JPanel();
        JButton addButton = new JButton("Add");
        JButton deleteButton = new JButton("Delete");

        buttonPanel.add(addButton);
        buttonPanel.add(deleteButton);

        panel.add(buttonPanel, BorderLayout.SOUTH);

        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String[] values = new String[dbFields.length];
                for (int i = 0; i < dbFields.length; i++) {
                    values[i] = textFields[i].getText();
                }
                if (addToDatabase(tableName, dbFields, values)) {
                    tableModel.addRow(values);
                    clearTextFields(textFields);
                }
            }
        });



        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = table.getSelectedRow();
                if (selectedRow != -1) {
                    int id = (int) tableModel.getValueAt(selectedRow, 0); // Assuming the first column is the ID
                    if (deleteFromDatabase(tableName, id)) {
                        tableModel.removeRow(selectedRow);
                    }
                }
            }
        });

        return panel;
    }

    private void clearTextFields(JTextField[] textFields) {
        for (JTextField textField : textFields) {
            textField.setText("");
        }
    }

    private void connectToDatabase() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/ScheduleDB"; // Change URL, username, and password accordingly
            String username = "root";
            String password = "";
            connection = DriverManager.getConnection(url, username, password);
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    private boolean addToDatabase(String tableName, String[] dbFields, String[] values) {
        if (connection != null) {
            String query = "INSERT INTO " + tableName + " (" + String.join(", ", dbFields) + ") VALUES (";
            for (int i = 0; i < values.length; i++) {
                query += "?, ";
            }
            query = query.substring(0, query.length() - 2) + ")";
            try (PreparedStatement statement = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
                for (int i = 0; i < values.length; i++) {
                    statement.setString(i + 1, values[i]);
                }
                statement.executeUpdate();
                ResultSet rs = statement.getGeneratedKeys();
                if (rs.next()) {
                    int id = rs.getInt(1);
                    // Assuming the ID column is the first column
                    return true;
                }
            } catch (SQLException e) {
                e.printStackTrace();
                return false;
            }
        }
        return false;
    }

    private boolean deleteFromDatabase(String tableName, int id) {
        if (connection != null) {
            String query = "DELETE FROM " + tableName + " WHERE id = ?";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setInt(1, id);
                int affectedRows = statement.executeUpdate();
                return affectedRows > 0;
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return false;
    }


    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            ScheduleApp app = new ScheduleApp();
            app.setVisible(true);
        });
    }
}
